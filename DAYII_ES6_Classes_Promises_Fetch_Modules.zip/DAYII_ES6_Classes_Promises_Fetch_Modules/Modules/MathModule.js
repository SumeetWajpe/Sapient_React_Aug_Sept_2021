export function Add(x, y) {
  return x + y;
}
// one default export per module !
export function Multiply(x, y) {
  return x * y;
}
