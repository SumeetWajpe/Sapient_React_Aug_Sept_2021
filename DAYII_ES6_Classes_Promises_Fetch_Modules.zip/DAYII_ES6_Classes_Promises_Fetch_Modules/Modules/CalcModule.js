import * as MathModule from "./MathModule.js";

console.log(`Product is : ${MathModule.Multiply(20, 30)}`);

// import Product from "./MathModule.js";
// console.log(`Product is : ${Product(20, 30)}`);

// import { Add } from "./MathModule.js";
// console.log(`Addition is : ${Add(20, 30)}`);
