function GetPosts() {
  return new Promise((resolve, reject) => {
    let xmlHttpReq = new XMLHttpRequest();
    xmlHttpReq.open("GET", "https://jsonplaceholder.typicode.com/posts");
    xmlHttpReq.send();
    xmlHttpReq.onreadystatechange = function () {
      if (xmlHttpReq.status === 200 && xmlHttpReq.readyState === 4) {
        // success
        resolve(JSON.parse(xmlHttpReq.responseText));
      } else if (xmlHttpReq.status !== 200 && xmlHttpReq.readyState === 4) {
        // error
        reject(xmlHttpReq.status);
      }
    };
  });
}
