import React from "react";

export const CoursesWithLikes = (props) => {
  return (
    <div>
      <h2>Courses with likes </h2>
      <ul className="list-group col-md-2">
        {props.allCourses.map((course) => (
          <li key={course.id} className="list-group-item">
            <strong>{course.name}</strong>{" "}
            <i className="bi bi-hand-thumbs-up-fill text-primary"></i>{" "}
            {course.likes}
          </li>
        ))}
      </ul>
    </div>
  );
};
