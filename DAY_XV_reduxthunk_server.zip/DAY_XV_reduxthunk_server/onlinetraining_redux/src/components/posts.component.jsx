import axios from "axios";
import React, { useEffect } from "react";
import { Link } from "react-router-dom";

function Posts(props) {
  useEffect(() => {
    props.FetchPostsAsync();
  }, []);

  let allPostsToBeCreated = props.allPosts.map((post) => (
    <li className="list-group-item" key={post.id}>
      <Link to={"/postdetails/" + post.id}> {post.title} </Link>
    </li>
  ));
  return (
    <div>
      <h1>All Posts</h1>
      <ul className="list-group">
        {props.allPosts.length === 0 ? (
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        ) : (
          allPostsToBeCreated
        )}
      </ul>
    </div>
  );
}

export default Posts;
