import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import App from "./App";
import * as AllActions from "../actions/actionCreators";

// expose store data as props
function mapStateToProps(store) {
  return {
    allCourses: store.courses,
    allPosts: store.posts,
  };
}

// expose Action Creators as props
function mapDispatchToProps(dispatcher) {
  return bindActionCreators(AllActions, dispatcher);
}

var MainApp = connect(mapStateToProps, mapDispatchToProps)(App);
export default MainApp;

// function Outer() {
//   return function (msg) {
//     console.log(msg);
//   };
// }

// var inner = Outer();
// inner();

// Outer()("Within inner !");
