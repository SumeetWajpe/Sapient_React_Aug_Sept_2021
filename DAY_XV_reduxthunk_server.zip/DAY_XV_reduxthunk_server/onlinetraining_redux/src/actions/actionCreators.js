// const ADD_COURSE = 'ADD_COURSE';
import axios from "axios";
export function AddCourse(newcourse) {
  return { type: "ADD_COURSE", newcourse };
}

export function DeleteCourse(theCourseId) {
  return { type: "DELETE_COURSE", theCourseId };
}

export function IncrementLikes(theCourseId) {
  return { type: "INCREMENT_LIKES", theCourseId };
}

export function DeletePost() {
  return { type: "DELETE_POST" };
}

export function FetchPosts(posts) {
  return { type: "FETCH_POSTS", posts };
}

export function FetchPostsAsync() {
  return (dispatch) => {
    axios
      .get("https://jsonplaceholder.typicode.com/posts")
      .then((response) => dispatch(FetchPosts(response.data)));
  };
}
