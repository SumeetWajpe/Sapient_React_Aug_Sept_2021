import React, { useContext } from "react";

var CounterContext = React.createContext();
var AgeContext = React.createContext();

export class CounterProvider extends React.Component {
  constructor(props) {
    super(props);
    this.state = { count: 100 };
  }
  render() {
    return (
      <CounterContext.Provider
        value={{
          counterstate: this.state,
          incrementCount: () => this.setState({ count: this.state.count + 1 }),
        }}
      >
        {this.props.children}
      </CounterContext.Provider>
    );
  }
}

export class GrandParent extends React.Component {
  render() {
    return (
      <CounterProvider>
        <Parent />
      </CounterProvider>
    );
  }
}

export class Parent extends React.Component {
  render() {
    return (
      <AgeContext.Provider value={20}>
        <div>
          <Child />
          <AnotherChild />
        </div>
      </AgeContext.Provider>
    );
  }
}

export class Child extends React.Component {
  render() {
    return (
      <CounterContext.Consumer>
        {(context) => (
          <div>
            <h2>Child</h2>
            <p>Count is : {context.counterstate.count}</p>
            <input
              type="button"
              className="btn btn-primary btn-sm"
              value="++"
              onClick={context.incrementCount}
            />
            <AgeContext.Consumer>
              {(ctx) => <p>Age :{ctx}</p>}
            </AgeContext.Consumer>
          </div>
        )}
      </CounterContext.Consumer>
    );
  }
}

// export function AnotherChild() {
//   return (
//     <CounterContext.Consumer>
//       {(value) => (
//         <div>
//           <h2>Another Child</h2>
//           <p>Count is : {value.counterstate.count}</p>
//         </div>
//       )}
//     </CounterContext.Consumer>
//   );
// }

export function AnotherChild() {
  const countercontext = useContext(CounterContext);
  const agecontext = useContext(AgeContext);

  return (
    <div>
      <h2>Another Child</h2>
      <p>Count is : {countercontext.counterstate.count}</p>
      <p>Age is : {agecontext}</p>
    </div>
  );
}
