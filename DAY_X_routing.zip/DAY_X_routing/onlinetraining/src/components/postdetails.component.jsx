import React from "react";

export const Postdetails = (props) => {
  let {
    match: {
      params: { id },
    },
  } = props;

  return (
    <div>
      <h1>Post Details for {id} </h1>
    </div>
  );
};
