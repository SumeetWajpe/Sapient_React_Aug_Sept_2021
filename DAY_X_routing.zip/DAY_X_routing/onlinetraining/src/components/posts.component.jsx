import React from "react";
import axios from "axios";

class Posts extends React.Component {
  constructor(props) {
    super(props);
    this.state = { posts: [] };
  }
  componentDidMount() {
    axios
      .get("https://jsonplaceholder.typicode.com/posts")
      .then((response) => this.setState({ posts: response.data }));
    // axios
    //   .get("https://jsonplaceholder.typicode.com/posts")
    //   .then(function (response) {
    //     this.setState({ posts: response.data });
    //   });
  }
  render() {
    let postsToBeCreated = this.state.posts.map((post) => (
      <li className="list-group-item" key={post.id}>
        {post.title}
      </li>
    ));
    return (
      <div>
        <h1>All Posts</h1>
        <ul className="list-group">{postsToBeCreated}</ul>
      </div>
    );
  }
}

export default Posts;
