import React from "react";
import { useForm } from "react-hook-form";

export const NewCourseReactHookForm = () => {
  const {
    register,
    watch,
    handleSubmit,
    formState: { errors },
  } = useForm();
  //   console.log(watch());
  console.log(errors);
  return (
    <div className="col-md-4">
      <form
        onSubmit={handleSubmit((data) => {
          //console.log(data);
        })}
      >
        <label htmlFor="txtCourseId">
          <span style={{ color: "red" }}>*</span> Id :
        </label>
        <input
          type="text"
          className="form-control"
          {...register("CourseId", {
            required: "The Course Id is required !",
          })}
        />
        {errors.CourseId && (
          <p style={{ color: "red" }}>{errors.CourseId.message}</p>
        )}
        <label htmlFor="txtCourseName">
          <span style={{ color: "red" }}>*</span> Name :
        </label>

        <input
          type="text"
          className="form-control"
          placeholder="Coursename maxlength 20"
          {...register("CourseName", {
            required: "Course Name is required !",
            maxLength: { value: 20, message: "You exceeded maxlength 20 !" },
          })}
        />
        {errors.CourseName && (
          <p style={{ color: "red" }}>{errors.CourseName.message}</p>
        )}
        <input
          type="submit"
          value="Add New Course"
          className="btn btn-success"
        />
      </form>
    </div>
  );
};
