import ListOfCourses from "./components/listofcourses.component";
import Posts from "./components/posts.component";
import Message from "./components/functional.component";
import Counter from "./components/counter.statehook";
import PostsWithEffects from "./components/posts.effecthook";
import { GrandParent } from "./components/contextapi";
import Login from "./components/login.component";
import { NewCourse } from "./components/newcourse.component";
import { NewCourseReactHookForm } from "./components/newcourse_reacthookform";
import { BrowserRouter, Route, Switch, Link, Redirect } from "react-router-dom";
import { Postdetails } from "./components/postdetails.component";
function App() {
  // config
  return (
    <div>
      <BrowserRouter>
        <nav className="navbar navbar-expand-lg navbar-light bg-light">
          <Link className="navbar-brand" to="/">
            Online Training
          </Link>
          <button
            className="navbar-toggler"
            type="button"
            data-toggle="collapse"
            data-target="#navbarNav"
            aria-controls="navbarNav"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav">
              <li className="nav-item">
                <Link className="nav-link" to="/">
                  Home
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/posts">
                  Posts
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/newcourse">
                  New Course
                </Link>
              </li>
            </ul>
          </div>
        </nav>
        <Switch>
          <Route path="/" component={ListOfCourses} exact></Route>
          <Route path="/posts" component={PostsWithEffects}></Route>
          <Route path="/postdetails/:id" component={Postdetails}></Route>
          <Route path="/newcourse" component={NewCourse}></Route>
          <Route path="/msg" render={() => <Message msg="Hello" />}></Route>

          {/* <Route path="**" component={ErrorComponent}></Route> */}
          {/* <Route
            path="**"
            render={() => (
              <h1 style={{ color: "red" }}>Resource not found !</h1>
            )}
          ></Route> */}
          <Route path="**" render={() => <Redirect to="/"></Redirect>}></Route>
        </Switch>
      </BrowserRouter>
    </div>
  );
}

export default App;
