import axios from "axios";
import React, { useEffect, useState } from "react";

export const Postdetails = (props) => {
  let {
    match: {
      params: { id = 1 },
    },
  } = props;

  const [thePost, setThePost] = useState({});

  useEffect(() => {
    axios
      .get("https://jsonplaceholder.typicode.com/posts/" + id)
      .then((response) => setThePost(response.data));
  }, [id]);

  return (
    <div className="alert alert-secondary">
      <h1>Post Details for {id || 1} </h1>
      <p>
        {" "}
        <strong>Id : </strong> {thePost.id}
      </p>
      <p>
        {" "}
        <strong>User Id :</strong> {thePost.userId}
      </p>
      <p>
        <strong>Title : </strong> {thePost.title}
      </p>
      <p>
        <strong>Body :</strong> {thePost.body}
      </p>
    </div>
  );
};

// import axios from "axios";
// import React, { useEffect, useState } from "react";

// export const Postdetails = (props) => {
//   let {
//     match: {
//       params: { id },
//     },
//   } = props;

//   const [thePost, setThePost] = useState({});

//   useEffect(() => {
//     axios
//       .get("https://jsonplaceholder.typicode.com/posts/" + id)
//       .then((response) => setThePost(response.data));
//   }, []);

//   return (
//     <div className="alert alert-secondary">
//       <h1>Post Details for {id} </h1>
//       <p>
//         {" "}
//         <strong>Id : </strong> {thePost.id}
//       </p>
//       <p>
//         {" "}
//         <strong>User Id :</strong> {thePost.userId}
//       </p>
//       <p>
//         <strong>Title : </strong> {thePost.title}
//       </p>
//       <p>
//         <strong>Body :</strong> {thePost.body}
//       </p>
//     </div>
//   );
// };
