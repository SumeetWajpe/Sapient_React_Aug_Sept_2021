var ModuleObject = require("./module");

console.log("Addition is : " + ModuleObject.Add(10, 20));
