export function posts(defStore = [], action) {
  switch (action.type) {
    case "FETCH_POSTS":
      console.log("Within FETCH_POSTS");
      return action.posts;
    case "DELETE_POST":
      console.log(defStore);

      console.log("Within Posts reducer ! : Delete Post");
      console.log(action);
      return defStore; // new store
    default:
      return defStore;
  }
}
