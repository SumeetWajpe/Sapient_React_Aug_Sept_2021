export function courses(defStore = [], action) {
  switch (action.type) {
    case "ADD_COURSE":
      console.log("Within Courses reducer ! :: ADD_COURSE");
      return [...defStore, action.newcourse]; // new store
    case "DELETE_COURSE":
      return defStore.filter((course) => course.id !== action.theCourseId);
    case "INCREMENT_LIKES":
      console.log(action.theCourseId);
      let theIndex = defStore.findIndex((c) => c.id == action.theCourseId);
      return [
        ...defStore.slice(0, theIndex),
        { ...defStore[theIndex], likes: defStore[theIndex].likes + 1 },
        ...defStore.slice(theIndex + 1),
      ];

    // return defStore.map((course) => {
    //   if (course.id === action.theCourseId) {
    //     course.likes += 1;
    //   }
    //   return course;
    // });

    default:
      return defStore;
  }
}
