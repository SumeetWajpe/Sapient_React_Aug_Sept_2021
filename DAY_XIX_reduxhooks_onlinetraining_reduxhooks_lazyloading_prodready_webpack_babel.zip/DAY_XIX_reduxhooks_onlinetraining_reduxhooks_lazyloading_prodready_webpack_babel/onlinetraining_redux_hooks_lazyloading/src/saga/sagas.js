import {
  take,
  takeEvery,
  call,
  put,
  takeLatest,
  delay,
  debounce,
  retry,
} from "redux-saga/effects";
import axios from "axios";

function* fetch_Posts_Async() {
  // do the side effect  | make async call
  //yield delay(3000);
  let response = yield call(
    axios.get,
    "https://jsonplaceholder.typicode.com/posts"
  );
  yield put({ type: "FETCH_POSTS", posts: response.data }); // dispatch an action
}

function CallPosts() {
  return axios.get("https://jsonplaceholder.typicode.com/posts");
}

function* retrySaga(data) {
  try {
    const SECONDS = 1000;
    const response = yield retry(3, 10 * SECONDS, CallPosts, data);
    yield put({ type: "FETCH_POSTS", posts: response.data });
  } catch (error) {
    yield put({ type: "FETCH_POSTS_ERROR", error });
  }
}

function* incrementLikes(action) {
  yield delay(1000);
  yield put({ type: "INCREMENT_LIKES", theCourseId: action.theCourseId });
}

export function* mySaga() {
  //yield takeEvery("FETCH_POSTS_ASYNC", fetch_Posts_Async);
  //yield takeLatest("FETCH_POSTS_ASYNC", fetch_Posts_Async);
  //   yield debounce(2000, "FETCH_POSTS_ASYNC", fetch_Posts_Async);
  //yield delay(10000);

  yield takeEvery("FETCH_POSTS_ASYNC", retrySaga);
  yield takeEvery("INCREMENT_LIKES_ASYNC", incrementLikes);
}
