class CourseModel {
  constructor(id, name, price, likes, imageUrl, rating) {
    this.id = id;
    this.name = name;
    this.price = price;
    this.likes = likes;
    this.imageUrl = imageUrl;
    this.rating = rating;
  }
}

export default CourseModel;
