import React from "react";
import { useDispatch, useSelector } from "react-redux";

import { useParams } from "react-router-dom";

export const Postdetails = (props) => {
  //   let {
  //     match: {
  //       params: { id = 1 },
  //     },
  //   } = props;

  var posts = useSelector((storeData) => storeData.posts);
  var dispatch = useDispatch();

  let { id = 1 } = useParams();

  let thePost = posts.find((p) => p.id == id);
  return (
    <div className="alert alert-secondary">
      <h1>Post Details for {id} </h1>
      <p>
        <strong>User Id : </strong> {thePost.userId}
      </p>
      <p>
        <strong>Title : </strong> {thePost.title}
      </p>
      <p>
        <strong>Body : </strong> {thePost.body}
      </p>
    </div>
  );
};

{
  /* <p>
        {" "}
        <strong>Id : </strong> {thePost.id}
      </p>
      <p>
        {" "}
        <strong>User Id :</strong> {thePost.userId}
      </p>
      <p>
        <strong>Title : </strong> {thePost.title}
      </p>
      <p>
        <strong>Body :</strong> {thePost.body}
      </p> */
}
