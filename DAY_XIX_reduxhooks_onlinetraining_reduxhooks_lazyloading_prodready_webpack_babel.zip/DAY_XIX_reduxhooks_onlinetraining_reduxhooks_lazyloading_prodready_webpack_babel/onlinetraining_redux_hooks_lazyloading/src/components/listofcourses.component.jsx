import React from "react";
import { useSelector } from "react-redux";
import { Course } from "./course.component";

export const ListOfCourses = () => {
  var courses = useSelector((storeData) => storeData.courses);
  let coursesToBeCreated = courses.map((course) => (
    <Course key={course.id} coursedetails={course} />
  ));
  return (
    <div>
      <h1> List Of Courses</h1>
      <div className="row">{coursesToBeCreated}</div>
    </div>
  );
};
