import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link } from "react-router-dom";
import { FetchPostsAsync } from "../actions/actionCreators";

function Posts() {
  var posts = useSelector((storeData) => storeData.posts);
  var dispatch = useDispatch();

  useEffect(() => {
    dispatch(FetchPostsAsync());
  }, []);

  let allPostsToBeCreated = posts.map((post) => (
    <li className="list-group-item" key={post.id}>
      <Link to={"/postdetails/" + post.id}> {post.title} </Link>
    </li>
  ));
  return (
    <div>
      <h1>All Posts</h1>

      <ul className="list-group">
        {posts.length === 0 ? (
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        ) : (
          allPostsToBeCreated
        )}
      </ul>
    </div>
  );
}

export default Posts;
