export function Increment(counter) {
  return { type: "INCREMENT_COUNT", counter };
}

export function Decrement(counter) {
  return { type: "DECREMENT_COUNT", counter };
}
