export function AddUser() {
  return { type: "ADD_USER" };
}
