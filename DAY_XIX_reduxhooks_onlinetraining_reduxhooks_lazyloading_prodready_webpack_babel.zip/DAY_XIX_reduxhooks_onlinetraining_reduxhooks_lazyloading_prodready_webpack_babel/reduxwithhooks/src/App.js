import "./App.css";
import MyCounter from "./Counter";

function App() {
  return (
    <div className="App">
      <MyCounter />
    </div>
  );
}

export default App;
