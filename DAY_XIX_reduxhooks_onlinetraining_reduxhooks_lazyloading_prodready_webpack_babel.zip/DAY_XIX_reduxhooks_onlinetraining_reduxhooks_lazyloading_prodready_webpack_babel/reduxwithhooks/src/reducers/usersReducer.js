export function users(defStore = {}, action) {
  switch (action.type) {
    case "ADD_USER":
      return defStore;
    default:
      return defStore;
  }
}
