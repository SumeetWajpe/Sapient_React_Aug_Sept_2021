export function counter(defStore = {}, action) {
  switch (action.type) {
    case "INCREMENT_COUNT":
      return action.counter + 1;
    case "DECREMENT_COUNT":
      return action.counter - 1;

    default:
      return defStore;
  }
}
