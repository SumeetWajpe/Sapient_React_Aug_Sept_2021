import { combineReducers } from "redux";
import { counter } from "./counterReducer";
import { users } from "./usersReducer";

var rootReducer = combineReducers({ counter, users });
export default rootReducer;
