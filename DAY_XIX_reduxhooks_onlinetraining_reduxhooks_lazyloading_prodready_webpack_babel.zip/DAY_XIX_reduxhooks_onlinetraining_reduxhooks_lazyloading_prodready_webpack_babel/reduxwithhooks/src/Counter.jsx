import React from "react";
import { useDispatch, useSelector } from "react-redux";
// import { Increment } from "./actions/actionCreators";
import * as allCounterActions from "./actions/counterActionCreators";
function MyCounter() {
  var currCount = useSelector((storeData) => storeData.counter);
  var dispatch = useDispatch();
  return (
    <div>
      <p>Count : {currCount}</p>
      <input
        type="button"
        value="++"
        onClick={() => dispatch(allCounterActions.Increment(currCount))}
      />
      <input
        type="button"
        value="--"
        onClick={() => dispatch(allCounterActions.Decrement(currCount))}
      />
    </div>
  );
}

export default MyCounter;
