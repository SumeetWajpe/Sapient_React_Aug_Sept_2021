import { createStore } from "redux";
import rootReducer from "../reducers/rootReducer";

var defStoreData = { counter: 10, users: [{ id: 1, name: "DummyUser" }] };

const store = createStore(rootReducer, defStoreData);
export default store;
