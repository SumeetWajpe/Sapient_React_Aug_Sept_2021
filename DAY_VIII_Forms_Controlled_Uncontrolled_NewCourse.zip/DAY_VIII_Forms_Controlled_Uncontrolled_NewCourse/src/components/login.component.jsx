// import React from "react";

// export default class Login extends React.Component {
//   constructor(props) {
//     super(props);
//     this.state = { uname: "Dummy" };
//   }
//   render() {
//     return (
//       <form>
//         <label htmlFor="txtUsername">Username : </label>
//         <input type="text" id="txtUsername" value={this.state.uname} />
//         <input
//           type="button"
//           value="Login"
//           onClick={() => {
//             this.setState({ uname: "AnotherDummy" });
//           }}
//         />

//         <h2>{this.state.uname}</h2>
//       </form>
//     );
//   }
// }

// import React from "react";

// export default class Login extends React.Component {
//   constructor(props) {
//     super(props);
//     this.txtUnameRef = React.createRef();
//   }
//   render() {
//     return (
//       <form>
//         <label htmlFor="txtUsername">Username : </label>
//         <input type="text" id="txtUsername" ref={this.txtUnameRef} />
//         <input
//           type="button"
//           value="Login"
//           onClick={() => {
//             console.log(this.txtUnameRef.current.value);
//           }}
//         />
//       </form>
//     );
//   }
// }
