// import React, { useState } from "react"; // 16.8

// export default function Counter() {
//   // Declare a new state variable, which we'll call "count"

//   //   useState -> [initial value,function setTheState(){}]
//   const [counter, setCounter] = useState({ count: 0, age: 20 });

//   return (
//     <div>
//       <p>You clicked {counter.count} times</p>
//       <p>Your age is {counter.age}</p>

//       <button
//         onClick={() => setCounter({ ...counter, count: counter.count + 1 })}
//       >
//         Count++
//       </button>
//       <button onClick={() => setCounter({ ...counter, age: counter.age + 10 })}>
//         Age ++
//       </button>
//     </div>
//   );
// }

import React, { useState } from "react"; // 16.8

export default function Counter() {
  // Declare a new state variable, which we'll call "count"

  //   useState -> [initial value,function setTheState(){}]
  const [count, setCount] = useState(0);
  const [age, setAge] = useState(20);

  return (
    <div>
      <p>You clicked {count} times</p>
      <p>Your age is {age}</p>

      <button onClick={() => setCount(count + 1)}>Count++</button>
      <button onClick={() => setAge(age + 10)}>Age ++</button>
    </div>
  );
}
