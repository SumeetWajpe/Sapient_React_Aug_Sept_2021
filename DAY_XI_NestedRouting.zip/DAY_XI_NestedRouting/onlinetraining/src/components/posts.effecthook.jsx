import axios from "axios";
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

function PostsWithEffects() {
  const [allPosts, setAllPosts] = useState([]);

  useEffect(() => {
    axios
      .get("https://jsonplaceholder.typicode.com/posts")
      .then((response) => setAllPosts(response.data));
  }, []);

  let allPostsToBeCreated = allPosts.map((post) => (
    <li className="list-group-item" key={post.id}>
      <Link to={"/postdetails/" + post.id}> {post.title} </Link>
    </li>
  ));

  //   var loading = (
  //     <div class="spinner-border text-primary" role="status">
  //       <span class="visually-hidden">Loading...</span>
  //     </div>
  //   );
  //   var content = null;
  //   if (allPosts.length == 0) {
  //     content = loading;
  //   } else {
  //     content = allPostsToBeCreated;
  //   }

  return (
    <div>
      <h1>All Posts</h1>
      <ul className="list-group">
        {allPosts.length === 0 ? (
          <div class="spinner-border text-primary" role="status">
            <span class="visually-hidden">Loading...</span>
          </div>
        ) : (
          allPostsToBeCreated
        )}
      </ul>
    </div>
  );
}

export default PostsWithEffects;

// import axios from "axios";
// import React, { useEffect, useState } from "react";

// function PostsWithEffects() {
//   const [postId, setPostId] = useState(1);
//   const [thePost, setThePost] = useState({});

//   const [userId, setUserId] = useState(1);
//   const [theUser, setTheUser] = useState({});

//   useEffect(() => {
//     axios
//       .get("https://jsonplaceholder.typicode.com/posts/" + postId)
//       .then((response) => setThePost(response.data));
//   }, [postId]);

//   useEffect(() => {
//     axios
//       .get("https://jsonplaceholder.typicode.com/users/" + userId)
//       .then((response) => setTheUser(response.data));
//   }, [userId]);

//   return (
//     <div>
//       <h1>Post Title for : {postId}</h1>
//       <input
//         type="button"
//         value="Post Id++"
//         onClick={() => {
//           setPostId(postId + 1);
//           setUserId(userId + 1);
//         }}
//       />
//       <p>Title : {thePost.title}</p>
//       <p>User : {theUser.name}</p>
//     </div>
//   );
// }

// export default PostsWithEffects;
