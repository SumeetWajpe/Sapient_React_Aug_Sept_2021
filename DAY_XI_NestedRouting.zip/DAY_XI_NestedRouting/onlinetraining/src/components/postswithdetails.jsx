import axios from "axios";
import React, { useEffect, useState } from "react";
import { Link, Router } from "react-router-dom";

function PostsWithDetails(props) {
  const [allPosts, setAllPosts] = useState([]);

  useEffect(() => {
    axios
      .get("https://jsonplaceholder.typicode.com/posts")
      .then((response) => setAllPosts(response.data));
  }, []);

  let allPostsToBeCreated = allPosts.map((post) => (
    <li className="list-group-item" key={post.id}>
      <Link to={"/posts/details/" + post.id}> {post.title} </Link>
    </li>
  ));

  return (
    <div className="row">
      <h1>All Posts</h1>
      <ul className="list-group col-md-5">
        {allPosts.length === 0 ? (
          <div class="spinner-border text-primary" role="status">
            <span class="visually-hidden">Loading...</span>
          </div>
        ) : (
          allPostsToBeCreated
        )}
      </ul>
      <div
        className="col-md-5"
        style={{ position: "fixed", top: "110px", right: "100px" }}
      >
        {props.children}
      </div>
    </div>
  );
}

export default PostsWithDetails;
