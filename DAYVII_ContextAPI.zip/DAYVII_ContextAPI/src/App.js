import ListOfCourses from "./components/listofcourses.component";
import Posts from "./components/posts.component";
import Message from "./components/functional.component";
import Counter from "./components/counter.statehook";
import PostsWithEffects from "./components/posts.effecthook";
import { GrandParent } from "./components/contextapi";
function App() {
  // config
  return (
    <div>
      {/* <ListOfCourses /> */}
      {/* <Posts></Posts> */}
      {/* <Message msg="Hola" /> */}
      {/* <Counter /> */}
      {/* <PostsWithEffects /> */}
      <GrandParent />
    </div>
  );
}

export default App;
