import ListOfCourses from "./components/listofcourses.component";
import Posts from "./components/posts.component";
import Message from "./components/functional.component";
import Counter from "./components/counter.statehook";
import PostsWithEffects from "./components/posts.effecthook";
import { GrandParent } from "./components/contextapi";
import Login from "./components/login.component";
import { NewCourse } from "./components/newcourse.component";
import { NewCourseReactHookForm } from "./components/newcourse_reacthookform";
function App() {
  // config
  return (
    <div>
      {/* <ListOfCourses /> */}
      {/* <Posts></Posts> */}
      {/* <Message msg="Hola" /> */}
      {/* <Counter /> */}
      {/* <PostsWithEffects /> */}
      {/* <GrandParent /> */}
      {/* <Login /> */}
      <NewCourse />
      {/* <NewCourseReactHookForm /> */}
    </div>
  );
}

export default App;
