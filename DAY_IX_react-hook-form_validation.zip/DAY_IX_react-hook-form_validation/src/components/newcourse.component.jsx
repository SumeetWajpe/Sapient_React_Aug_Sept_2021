import React, { useState } from "react";

export const NewCourse = (props) => {
  const [newCourse, setNewCourse] = useState({
    id: 0,
    name: "",
    price: 0,
    likes: 0,
    rating: 0,
    imageUrl: "",
  });

  const [error, setError] = useState("");
  return (
    <div className="col-md-4">
      <h2>New Course : </h2>
      <form>
        <label htmlFor="txtCourseId"> Id : </label>
        <input
          type="text"
          id="txtCourseId"
          className="form-control"
          value={newCourse.id}
          onBlur={() => console.log("Blur")}
          onChange={(e) => {
            if (e.target.value === "") {
              setError("The Id is required !");
            } else {
              setError("");
            }
            setNewCourse({ ...newCourse, id: e.target.value });
          }}
        />
        {error != "" ? <p style={{ color: "red" }}>{error}</p> : ""}
        <label htmlFor="txtCoursename">Name : </label>
        <input
          type="text"
          id="txtCoursename"
          className="form-control"
          value={newCourse.name}
          onChange={(e) => {
            setNewCourse({ ...newCourse, name: e.target.value });
          }}
        />
        <label htmlFor="txtCourseprice">Price : </label>
        <input
          type="text"
          id="txtCourseprice"
          className="form-control"
          value={newCourse.price}
          onChange={(e) => {
            setNewCourse({ ...newCourse, price: e.target.value });
          }}
        />
        <label htmlFor="txtCourserating">Rating : </label>
        <input
          type="text"
          id="txtCourserating"
          className="form-control"
          value={newCourse.rating}
          onChange={(e) => {
            setNewCourse({ ...newCourse, rating: e.target.value });
          }}
        />
        <label htmlFor="txtCourselikes">Likes : </label>
        <input
          type="text"
          id="txtCourselikes"
          className="form-control"
          value={newCourse.likes}
          onChange={(e) => {
            setNewCourse({ ...newCourse, likes: e.target.value });
          }}
        />
        <label htmlFor="txtCourseimage">Image Url : </label>
        <input
          type="text"
          id="txtCourseimage"
          className="form-control"
          value={newCourse.imageUrl}
          onChange={(e) => {
            setNewCourse({ ...newCourse, imageUrl: e.target.value });
          }}
        />
        <input
          type="button"
          value="Add"
          className="btn btn-success m-1"
          onClick={() => {
            console.log(newCourse);
          }}
        />
      </form>
    </div>
  );
};
