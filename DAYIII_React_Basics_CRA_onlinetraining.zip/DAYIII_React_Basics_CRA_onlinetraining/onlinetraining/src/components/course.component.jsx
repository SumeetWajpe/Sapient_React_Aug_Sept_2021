import React from "react";
import "../styles/course.styles.css";
class Course extends React.Component {
  constructor(props) {
    super(props);
    this.state = { currCount: this.props.coursedetails.likes };
  }
  IncrementLikes() {
    // this.props.coursedetails.likes++; // doesn't work as for React props are readonly
    //this.state.currCount++; // state is immutable !
    this.setState({ currCount: this.state.currCount + 1 });
  }
  render() {
    return (
      <div className="col-md-3">
        <div className="card m-1">
          <img
            height="150px"
            width="200px"
            src={this.props.coursedetails.imageUrl}
            alt={this.props.coursedetails.name}
            className="card-img-top"
          />
          <div className="card-body">
            <i className="bi bi-star-fill"></i>
            <i className="bi bi-star-fill"></i>
            <i className="bi bi-star-fill"></i>
            <i className="bi bi-star-fill"></i>
            <i className="bi bi-star-fill"></i>

            <h5 className="card-title">{this.props.coursedetails.name}</h5>
            <h6 className="card-text">₹. {this.props.coursedetails.price}</h6>
            {/* <p className="card-text">{this.props.coursedetails.likes}</p> */}
            {/* <p className="card-text">{this.props.coursedetails.rating}</p> */}
            <button
              className="btn btn-primary btn-sm"
              onClick={this.IncrementLikes.bind(this)}
            >
              <i className="bi bi-hand-thumbs-up"></i>{" "}
              {/* {this.props.coursedetails.likes} */}
              {this.state.currCount}
            </button>
          </div>
        </div>
      </div>
    );
  }
}

export default Course;
