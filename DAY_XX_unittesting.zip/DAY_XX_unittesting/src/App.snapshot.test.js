import React from "react";
import renderer from "react-test-renderer";
import App from "./App";

describe("test counter snapshot", () => {
  it("renders correct DOM tree", () => {
    const tree = renderer.create(<App />).toJSON();
    expect(tree).toMatchSnapshot();
  });
});
