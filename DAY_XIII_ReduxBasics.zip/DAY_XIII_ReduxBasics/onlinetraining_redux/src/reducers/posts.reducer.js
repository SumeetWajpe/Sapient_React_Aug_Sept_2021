export function posts(defStore = [], action) {
  return defStore; // new store
}
