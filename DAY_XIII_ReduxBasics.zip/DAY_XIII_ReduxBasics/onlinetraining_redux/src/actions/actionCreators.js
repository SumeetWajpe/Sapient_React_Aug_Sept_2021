// const ADD_COURSE = 'ADD_COURSE';
export function AddCourse() {
  return { type: "ADD_COURSE" };
}

export function DeleteCourse() {
  return { type: "DELETE_COURSE" };
}

export function IncrementLikes() {
  return { type: "INCREMENT_LIKES" };
}

export function DeletePost() {
  return { type: "DELETE_POST" };
}
