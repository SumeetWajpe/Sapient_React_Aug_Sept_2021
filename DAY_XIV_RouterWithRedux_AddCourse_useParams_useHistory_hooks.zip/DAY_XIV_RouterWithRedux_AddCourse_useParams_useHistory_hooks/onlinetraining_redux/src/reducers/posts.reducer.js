export function posts(defStore = [], action) {
  switch (action.type) {
    case "DELETE_POST":
      console.log(defStore);

      console.log("Within Posts reducer !");
      console.log(action);
      return defStore; // new store
    default:
      return defStore;
  }
}
