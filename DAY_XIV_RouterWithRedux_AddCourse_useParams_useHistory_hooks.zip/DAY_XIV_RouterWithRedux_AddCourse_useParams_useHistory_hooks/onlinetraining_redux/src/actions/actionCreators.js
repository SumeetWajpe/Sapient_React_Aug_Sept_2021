// const ADD_COURSE = 'ADD_COURSE';
export function AddCourse(newcourse) {
  return { type: "ADD_COURSE", newcourse };
}

export function DeleteCourse(theCourseId) {
  return { type: "DELETE_COURSE", theCourseId };
}

export function IncrementLikes(theCourseId) {
  return { type: "INCREMENT_LIKES", theCourseId };
}

export function DeletePost() {
  return { type: "DELETE_POST" };
}
