import axios from "axios";
import React from "react";
import { Link } from "react-router-dom";

function Posts(props) {
  //   useEffect(() => {
  //     axios
  //       .get("https://jsonplaceholder.typicode.com/posts")
  //       .then((response) => setAllPosts(response.data));
  //   }, []);

  let allPostsToBeCreated = props.allPosts.map((post) => (
    <li className="list-group-item" key={post.id}>
      <Link to={"/postdetails/" + post.id}> {post.title} </Link>
    </li>
  ));
  return (
    <div>
      <h1>All Posts</h1>
      <ul className="list-group">
        {props.allPosts.length === 0 ? (
          <div class="spinner-border text-primary" role="status">
            <span class="visually-hidden">Loading...</span>
          </div>
        ) : (
          allPostsToBeCreated
        )}
      </ul>
    </div>
  );
}

export default Posts;
