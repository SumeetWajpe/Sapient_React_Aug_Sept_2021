import { createStore } from "redux";
import CourseModel from "../model/course.model";
import rootReducer from "../reducers/root.reducer";

//createStore(reducer,defStoreData)

var defaultStoreData = {
  courses: [
    new CourseModel(
      1,
      "React",
      5000,
      200,
      "https://miro.medium.com/max/3840/1*yjH3SiDaVWtpBX0g_2q68g.png",
      5
    ),
    new CourseModel(
      2,
      "Redux",
      6000,
      500,
      "https://logicalidea.co/wp-content/uploads/2020/05/Redux.jpg",
      4
    ),
    new CourseModel(
      3,
      "Angular",
      3000,
      100,
      "https://bs-uploads.toptal.io/blackfish-uploads/blog/post/seo/og_image_file/og_image/15991/top-18-most-common-angularjs-developer-mistakes-41f9ad303a51db70e4a5204e101e7414.png",
      3
    ),
    new CourseModel(
      4,
      "Vue",
      5000,
      500,
      "https://xpertlab.com/wp-content/uploads/2020/10/1_wFL3csJ96lQpY0IVT9SE3w.jpeg",
      5
    ),
    new CourseModel(
      5,
      "Flutter",
      8000,
      200,
      "https://miro.medium.com/max/2000/1*PCKC8Ufml-wvb9Vjj3aaWw.jpeg",
      5
    ),
  ],
  posts: [{ id: 1, title: "First Post" }],
};

var store = createStore(rootReducer, defaultStoreData);
export default store;
