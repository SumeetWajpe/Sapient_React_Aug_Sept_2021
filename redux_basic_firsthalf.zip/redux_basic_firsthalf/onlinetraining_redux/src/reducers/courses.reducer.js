export function courses(defStore = [], action) {
  switch (action.type) {
    case "ADD_COURSE":
      console.log("Within Courses reducer !");
      console.log(action);
      return defStore; // new store
    case "DELETE_COURSE":
      return defStore;
    case "INCREMENT_LIKES":
      return defStore;

    default:
      return defStore;
  }
}
