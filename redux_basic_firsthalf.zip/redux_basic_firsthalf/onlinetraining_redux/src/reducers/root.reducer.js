import { combineReducers } from "redux";
import { courses } from "./courses.reducer";
import { posts } from "./posts.reducer";

var rootReducer = combineReducers({ posts, courses });
export default rootReducer;
