import React from "react";
import { Course } from "./course.component";

export const ListOfCourses = (props) => {
  let coursesToBeCreated = props.allCourses.map((course) => (
    <Course key={course.id} coursedetails={course} />
  ));
  return (
    <div>
      <h1> List Of Courses</h1>
      <div className="row">{coursesToBeCreated}</div>
    </div>
  );
};
