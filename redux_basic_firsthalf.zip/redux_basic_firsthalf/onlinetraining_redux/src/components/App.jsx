import { ListOfCourses } from "./listofcourses.component";
function App(props) {
  return (
    <div className="container">
      <ListOfCourses allCourses={props.allCourses} />
    </div>
  );
}

export default App;
