import { CoursesWithLikes } from "./courseswithlikes.component";
import { ListOfCourses } from "./listofcourses.component";
import { BrowserRouter, Route, Switch, Link } from "react-router-dom";
import Posts from "./posts.component";
import { NewCourseForm } from "./newcourse.component";
import { Postdetails } from "./postdetails.component";
function App(props) {
  return (
    <BrowserRouter>
      <div className="container">
        <nav className="navbar navbar-expand-lg navbar-light bg-light">
          <Link className="navbar-brand" to="/">
            Online Training
          </Link>
          <button
            className="navbar-toggler"
            type="button"
            data-toggle="collapse"
            data-target="#navbarNav"
            aria-controls="navbarNav"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav">
              <li className="nav-item">
                <Link className="nav-link" to="/">
                  Home
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/posts">
                  Posts
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/newcourse">
                  New Course
                </Link>
              </li>
            </ul>
          </div>
        </nav>

        <Switch>
          <Route path="/" exact>
            <ListOfCourses {...props} />
          </Route>
          <Route path="/posts">
            <Posts {...props} />
          </Route>
          <Route path="/newcourse">
            <NewCourseForm {...props} />
          </Route>
          <Route path="/postdetails/:id">
            <Postdetails {...props} />
          </Route>
        </Switch>
      </div>
    </BrowserRouter>
  );
}

export default App;
