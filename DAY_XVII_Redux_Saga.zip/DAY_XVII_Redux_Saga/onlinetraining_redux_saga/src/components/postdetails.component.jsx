import axios from "axios";
import React from "react";
import { useParams } from "react-router-dom";

export const Postdetails = (props) => {
  //   let {
  //     match: {
  //       params: { id = 1 },
  //     },
  //   } = props;

  let { id = 1 } = useParams();
  console.log(id);

  let thePost = props.allPosts.find((p) => p.id == id);
  return (
    <div className="alert alert-secondary">
      <h1>Post Details for {id} </h1>
      <p>
        <strong>Title : </strong> {thePost.title}
      </p>
    </div>
  );
};

{
  /* <p>
        {" "}
        <strong>Id : </strong> {thePost.id}
      </p>
      <p>
        {" "}
        <strong>User Id :</strong> {thePost.userId}
      </p>
      <p>
        <strong>Title : </strong> {thePost.title}
      </p>
      <p>
        <strong>Body :</strong> {thePost.body}
      </p> */
}
