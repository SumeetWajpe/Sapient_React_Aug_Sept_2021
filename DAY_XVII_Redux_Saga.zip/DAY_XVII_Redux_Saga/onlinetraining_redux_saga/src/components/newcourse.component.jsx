import React from "react";
import { useForm } from "react-hook-form";
import { useHistory } from "react-router-dom";
import CourseModel from "../model/course.model";

export const NewCourseForm = (props) => {
  const history = useHistory();
  const {
    register,
    watch,
    handleSubmit,
    formState: { errors },
  } = useForm();
  //   console.log(watch());
  return (
    <div className="col-md-4">
      <form
        onSubmit={handleSubmit((data) => {
          console.log(data);
          let newCourse = new CourseModel(
            data.CourseId,
            data.CourseName,
            data.CoursePrice,
            data.CourseLikes,
            data.CourseImage,
            data.CourseRating
          );
          props.AddCourse(newCourse);
        })}
      >
        <label htmlFor="txtCourseId">
          <span style={{ color: "red" }}>*</span> Id :
        </label>
        <input
          type="text"
          className="form-control"
          id="txtCourseId"
          {...register("CourseId", {
            required: "The Course Id is required !",
          })}
        />
        {errors.CourseId && (
          <p style={{ color: "red" }}>{errors.CourseId.message}</p>
        )}
        <label htmlFor="txtCourseName">
          <span style={{ color: "red" }}>*</span> Name :
        </label>
        <input
          type="text"
          className="form-control"
          id="txtCourseName"
          placeholder="Coursename maxlength 20"
          {...register("CourseName", {
            required: "Course Name is required !",
            maxLength: { value: 20, message: "You exceeded maxlength 20 !" },
          })}
        />
        {errors.CourseName && (
          <p style={{ color: "red" }}>{errors.CourseName.message}</p>
        )}
        <label htmlFor="txtCoursePrice">
          <span style={{ color: "red" }}>*</span> Price :
        </label>
        <input
          type="number"
          className="form-control"
          id="txtCoursePrice"
          {...register("CoursePrice")}
        />
        <label htmlFor="txtCourseLikes">
          <span style={{ color: "red" }}>*</span> Likes :
        </label>
        <input
          type="number"
          className="form-control"
          id="txtCourseLikes"
          {...register("CourseLikes")}
        />
        <label htmlFor="txtCourseRating">
          <span style={{ color: "red" }}>*</span> Rating :
        </label>
        <input
          type="number"
          className="form-control"
          id="txtCourseRating"
          {...register("CourseRating")}
        />
        <label htmlFor="txtCourseImage">
          <span style={{ color: "red" }}>*</span> Image Url :
        </label>
        <input
          type="text"
          className="form-control"
          id="txtCourseImage"
          {...register("CourseImage")}
        />
        <input
          type="submit"
          value="Add New Course"
          className="btn btn-success my-2"
        />{" "}
        <br />
        <input
          type="button"
          value="<<Go Back"
          className="btn btn-primary"
          onClick={() => history.goBack()}
        />{" "}
        <br />
      </form>
    </div>
  );
};
