// 1. No render method !
// 2. No componentLifeCycle Methods -> effectHook !
// 3. No State -> stateHook !

export default function Message(props) {
  return <h1>{props.msg} !</h1>;
}
