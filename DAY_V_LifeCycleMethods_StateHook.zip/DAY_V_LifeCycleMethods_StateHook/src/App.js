import ListOfCourses from "./components/listofcourses.component";
import Posts from "./components/posts.component";
import Message from "./components/functional.component";
import Counter from "./components/counter.statehook";
function App() {
  return (
    <div>
      {/* <ListOfCourses /> */}
      {/* <Posts></Posts> */}
      {/* <Message msg="Hola" /> */}
      <Counter />
    </div>
  );
}

export default App;
